/*
 * 작성일 : 
 * 작성자 :
 * 설명 : 조건식 연습.
 * 		 월을 입력받아 해당 계절을 출력하시오.
 * 		 3,4,5월 => 봄
 * 		 6,7,8월 => 여름
 * 		 9,10,11월 => 가을
 * 		 12,1,2월 => 겨울
 * 
 * 문제 분석 : 입력 받아야 할 값은 
 * 			 1,2,3,4,5,6,7,8,9,10,11,12이다.
 * 			 0이나 13을 입력하면? => 해당 월은 없습니다 출력하자.
 * 
 * 			 다중 if ?
 * 			 내포된 if ?
 */
public class ComConditionTest1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
